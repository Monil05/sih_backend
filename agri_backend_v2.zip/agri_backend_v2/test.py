import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()   # loads .env into os.environ

genai.configure(api_key=os.environ["GEMINI_API_KEY"])

model = genai.GenerativeModel("gemini-2.0-pro")  # or "gemini-1.5-pro" etc.

print(dir(model))
print(model._tools)   # check what tools are registered
print(model._tool_config)
